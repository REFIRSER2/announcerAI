@echo off

@REM frontend-libのビルド
cd client\typescript
call ncu.CMD -u
call pnpm install --force
call pnpm run build:prod
call pnpm version patch
call pnpm publish --no-git-checks
cd ..\..

@REM frontendのビルド。build:prodのなかでライセンス情報を作っている。
cd client\typescript-demo
call ncu.CMD -u
@REM  installだとエラーが出る。operation not permitted, unlink hogehoge.. 意味わからん。
@REM call pnpm install --force
@REM 下の処理がとまるときには手動でnode_packageを削除したのちにpnpm installを実行する。(多分ファイルロック周り？？？)
call pnpm update
call pnpm run build:prod
cd ..\..


@REM Pythonモジュールのラインセンス情報の生成
poetry run generate_license_file
copy licenses_by_license.json web_front\licenses-py.json

@REM バージョン番号のインクリメントとタグの作成
poetry version patch
poetry run generate_version_file --alpha False
git add pyproject.toml
git add ttsclient\version.txt
git add web_front\
git add *\package.json
git add *\package-lock.json
git add client\typescript-demo\public\assets\gui_settings\version.txt
git add client\typescript-demo\public\licenses-js.json
for /f %%i in ('poetry version -s') do set VERSION=%%i
git commit -m "Release v%VERSION%"
git push
git tag -a v%VERSION% -m "Release v%VERSION%"
git push origin --tags
