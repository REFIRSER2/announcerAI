import React, { useContext, useEffect, useState } from "react";
import { ReactNode } from "react";

export const DialogName = {
    none: "none",
    startingNoticeDialog: "startingNoticeDialog",
    modelSlotManagerMainDialog: "modelSlotManagerMainDialog",
    modelSlotManagerFileUploaderDialog: "modelSlotManagerFileUploaderDialog",
    modelSlotManagerSamplesDialog: "modelSlotManagerSamplesDialog",
    modelSlotManagerEditorDialog: "modelSlotManagerEditorDialog",
    voiceCharacterManagerMainDialog: "voiceCharacterManagerMainDialog",
    voiceCharacterManagerFileUploaderDialog: "voiceCharacterManagerFileUploaderDialog",
    advancedSettingDialog: "advancedSettingDialog",
    exportToOnnxDialog: "exportToOnnxDialog",
    mergeLabDialog: "mergeLabDialog",
    aboutModelDialog: "aboutModelDialog",
    aboutVoiceDialog: "aboutVoiceDialog",
    emotionColorDialog: "emotionColorDialog",
    voiceCharacterManagerSamplesDialog: "voiceCharacterManagerSamplesDialog",
} as const;
/* eslint-disable-next-line @typescript-eslint/no-redeclare */
export type DialogName = (typeof DialogName)[keyof typeof DialogName];

export const DialogName2 = {
    none: "none",
    textInputDialog: "textInputDialog",
    confirmDialog: "confirmDialog",
    waitDialog: "waitDialog",
    selectInputDialog: "selectInputDialog",
    colorSelectDialog: "colorSelectDialog",
    progressDialog: "progressDialog",
} as const;
/* eslint-disable-next-line @typescript-eslint/no-redeclare */
export type DialogName2 = (typeof DialogName2)[keyof typeof DialogName2];

type Props = {
    children: ReactNode;
};

type GuiStateAndMethod = {
    dialogName: DialogName;
    setDialogName: (val: DialogName) => void;
    dialog2Name: DialogName2;
    setDialog2Name: (val: DialogName2) => void;
    dialog2Props: Dialog2Props<any> | null;
    setDialog2Props: (val: Dialog2Props<any> | null) => void;

    progress: number;
    setProgress: (val: number) => void;
};

const GuiStateContext = React.createContext<GuiStateAndMethod | null>(null);
export const useGuiState = (): GuiStateAndMethod => {
    const state = useContext(GuiStateContext);
    if (!state) {
        throw new Error("useGuiState must be used within GuiStateProvider");
    }
    return state;
};

type Dialog2Props<T> = {
    title: string;
    instruction: string;
    resolve: (value: T | PromiseLike<T>) => void;
    defaultValue: T;
    options: { label: string; value: T }[] | null;
};

export const GuiStateProvider = ({ children }: Props) => {
    const [dialogName, setDialogName] = useState<DialogName>(DialogName.none);
    const [dialog2Name, setDialog2Name] = useState<DialogName2>(DialogName2.none);
    const [dialog2Props, setDialog2Props] = useState<Dialog2Props<any> | null>(null);
    const [progress, setProgress] = useState<number>(0);

    useEffect(() => {
        const url = new URL(location.href);
        const first = url.searchParams.get("first");
        if (first !== "false") {
            setDialogName("startingNoticeDialog");
        }
    }, []);

    const providerValue: GuiStateAndMethod = {
        dialogName,
        setDialogName,
        dialog2Name,
        setDialog2Name,
        dialog2Props,
        setDialog2Props,

        progress,
        setProgress,
    };

    return <GuiStateContext.Provider value={providerValue}>{children}</GuiStateContext.Provider>;
};
